// const express = require("express")
const fs = require("fs");
const mysql = require("mysql")
require('dotenv')
const csvParser = require('csv-parse');
// import { Blob } from 'buffer';
const blob = require('buffer')
const buffer = require('buffer')
// var app = express()
console.log("============blob=========",blob)

var connection = mysql.createConnection({
 host: "localhost",
 user : "root",
 password : "", 
 database : "hss_db",
 port : "3306"
});

 connection.connect((error)=>{
    if(error){
        console.log("error")
        console.log(error)
    }
    else {
        console.log("connected")
	    add()
    }
})

console.log("=========paths======",process.env.PATHS)


const add = async () =>{
    console.log("----------add data in db-------------")
    let id = 0
    let num = 0;
    let flag = 1;
    console.log("=======-----------",process.env.PATHS)
    const result = [];
    console.log("=========csv===================",csvParser)
    fs.createReadStream(process.env.PATHS)
    .pipe(csvParser.parse())
    .on("data", (data) => {
        result.push(data);
    })
    .on("end", async() => {
        // console.log("--------------",result);
        connection.query(`truncate table impi`);
        connection.query(`truncate table impu`);
        connection.query(`truncate table imsu`);
        connection.query(`truncate table impi_impu`);
        connection.query(`truncate table impu_visited_network`);
        for(let data of result){
            if(flag != 1){
                console.log("===============data=================",data)
                // let data1 = Object.assign({},data)
                // console.log("================data1============",data1)
                let imsi = data[0]
                let tel = data[1]
                let op = data[2]
                let kValue = data[3]
                let amf = data[4]
                let visited_network = data[5]
                id = id + 1
                // var myblobKValue = new blob.Blob([kValue], {
                //     type: 'text/plain'
                // });
                // // kValue = parseInt(kValue,16)
                // let op1=0x00000000000000000000000000000000
                // op1 = parseInt(op1.toString(2));
                // let amf1=0x8000
                // amf1 = parseInt(amf1.toString(2));
                // // console.log("===========================myblob",kValue)
                
                // var myblobAmf = new blob.Blob([amf], {
                //     type: 'text/plain'
                // });
                // amf = await myblobAmf.text()
                // var myblobOP = new blob.Blob([amf], {
                //     type: 'text/plain'
                // });
                // op = await myblobOP.text()
                // kValue = parseInt(kValue, 16).toString(2);
                // op = op.toString("utf8")
                // amf = amf.toString("utf8")
                // opc = opc.toString("utf8")
                console.log("-----------a+=======",imsi,"========tel========",tel,"============opc=========",op,"--------Kvalue-------",kValue,"=========amf======",amf,"===========visited network========",visited_network,"=======================myblob=====================")
                connection.query(`Insert into imsu values(${id},'${imsi}','','',1,1)`)
                const opstr = '0x00000000000000000000000000000000';
                imsi = imsi+'@ims.vzims.com'
                console.log("=======******imsi**********",imsi)
                console.log("-------------------------",connection.query(`Insert into impi values(${id},${id},'${imsi}',${kValue},1,1,${amf},${op},${opstr},'000000000001','','',0,3600,1)`));
                imsi = 'sip:'+imsi
                let id1 = id + num
                let id2 = id + id
                // console.log("---------------",id,"-------------------",id1,"---------------",id2,"-------------------------")
                let impu = 'tel:'+tel
                if(id == 1){
                    id1 = id + 1
                    connection.query(`Insert into impu values(${id},'${imsi}',0,0,0,1,${id1},1,'','',0,1)`)
                    connection.query(`Insert into impu_visited_network values(${id},${id},${visited_network})`)
                    connection.query(`Insert into impi_impu values(${id},${id},${id},0)`)
                    connection.query(`Insert into impu values(${id1},'${impu}',0,0,0,1,${id1},1,'','',0,1)`)
                    connection.query(`Insert into impu_visited_network values(${id1},${id1},1)`)
                    connection.query(`Insert into impi_impu values(${id1},${id},${id1},0)`)
                    num = num + 1
                }
                else{
                    connection.query(`Insert into impu values(${id1},'${imsi}',0,0,0,1,${id2},1,'','',0,1)`)
                    connection.query(`Insert into impu_visited_network values(${id1},${id1},1)`)
                    connection.query(`Insert into impi_impu values(${id1},${id},${id1},0)`)
                    connection.query(`Insert into impu values(${id2},'${impu}',0,0,0,1,${id2},1,'','',0,1)`)
                    connection.query(`Insert into impu_visited_network values(${id2},${id2},1)`)
                    connection.query(`Insert into impi_impu values(${id2},${id},${id2},0)`)
                    num = num + 1
                }
            }
            flag = 0
        }
        console.log("=====================Script Successfully Run================================")
    });
    // let data = await fs.readFileSync(`${process.env.PATHS}`).toString()
    // console.log("==========data===========",[data])
    // let array = data.split('\r')
    // array.pop()
    // console.log("======------------array----------",array)
    // for(imsi of array){
        // id = id + 1
        // console.log("-------------a+==========",imsi,"=========================b==============",imsi)
        // // console.log("------------------",typeof b)
        // connection.query(`Insert into imsu values(${id},'${imsi}','','',1,1)`)
        // const txt = '0x00112233445566778899AABBCCDDEEFF';
        // // const str2blob = txt => new Blob([txt]);
        // let amfstr = '0x8000';
        // // const str2blob1 = amfstr => new Blob([amfstr]);
        // const opstr = '0x00000000000000000000000000000000';
        // // const str2blob2 = opstr => new Blob([opstr]);
        // const opcstr = '0x62E75B8D6FA5BF46EC87A9276F9DF54D';
        // // const str2blob3 = opcstr => new Blob([opcstr]);
        // imsi = imsi+'@ims.mnc001.mcc001.3gppnetwork.org'
        // console.log("=======******b**********",imsi)
        // connection.query(`Insert into impi values(${id},${id},'${imsi}',${txt},1,1,${amfstr},${opstr},${opcstr},'000000000001','','',0,3600,1)`)
        // imsi = 'sip:'+imsi
        // let id1 = id + num
        // let id2 = id + id
        // console.log("---------------",id,"-------------------",id1,"---------------",id2,"-------------------------")
        // impuIdentity = impuIdentity + 1
        // let impu = 'tel:'+impuIdentity
        // if(id == 1){
        //     id1 = id + 1
        //     connection.query(`Insert into impu values(${id},'${imsi}',0,0,0,1,${id1},1,'','',0,1)`)
        //     connection.query(`Insert into impu_visited_network values(${id},${id},1)`)
        //     connection.query(`Insert into impi_impu values(${id},${id},${id},0)`)
        //     connection.query(`Insert into impu values(${id1},'${impu}',0,0,0,1,${id1},1,'','',0,1)`)
        //     connection.query(`Insert into impu_visited_network values(${id1},${id1},1)`)
        //     connection.query(`Insert into impi_impu values(${id1},${id},${id1},0)`)
        //     num = num + 1
        // }
        // else{
        //     connection.query(`Insert into impu values(${id1},'${imsi}',0,0,0,1,${id2},1,'','',0,1)`)
        //     connection.query(`Insert into impu_visited_network values(${id1},${id1},1)`)
        //     connection.query(`Insert into impi_impu values(${id1},${id},${id1},0)`)
        //     connection.query(`Insert into impu values(${id2},'${impu}',0,0,0,1,${id2},1,'','',0,1)`)
        //     connection.query(`Insert into impu_visited_network values(${id2},${id2},1)`)
        //     connection.query(`Insert into impi_impu values(${id2},${id},${id2},0)`)
        //     num = num + 1
        // }
    // }
}

